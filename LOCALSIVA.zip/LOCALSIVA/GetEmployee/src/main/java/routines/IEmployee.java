/**
 * IEmployee.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package routines;

public interface IEmployee extends java.rmi.Remote {
    public java.lang.String getID(java.lang.Integer empID) throws java.rmi.RemoteException;
    public routines.EmployeeClass getEmployeeInfo(routines.EmployeeClass employeeObject) throws java.rmi.RemoteException;
}
